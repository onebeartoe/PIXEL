package org.eh.core.other;

import org.junit.Test;

/**
 *
 * @author guojing
 * @date 2014-3-6
 */
public class StringTest {

	@Test
	public void testSub() {
		// String path = "test/path/list.do";
		// String suffix = path.substring(path.lastIndexOf("."), path.length());
		System.out.println(System.getProperty("user.dir"));
	}
}
