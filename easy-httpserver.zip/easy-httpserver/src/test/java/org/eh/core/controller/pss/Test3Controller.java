package org.eh.core.controller.pss;

import org.eh.core.annotation.Controller;

/**
 *
 * @author guojing
 * @date 2014-3-5
 */
@Controller(name = "test3", url = "/test/send")
public class Test3Controller {

}
