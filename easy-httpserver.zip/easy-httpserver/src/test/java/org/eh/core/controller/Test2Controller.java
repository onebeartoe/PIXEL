package org.eh.core.controller;

import org.eh.core.annotation.Controller;

/**
 *
 * @author guojing
 * @date 2014-3-5
 */
@Controller(name = "test2", url = "/test/list")
public interface Test2Controller {

}
