package org.eh.web.controller;

import org.eh.core.annotation.Controller;

/**
 *
 * @author guojing
 * @date 2014-3-5
 */
@Controller(name = "test1", url = "/test/mark")
public class Test1Controller {

}
