package org.eh.core.web.controller;


/**
 * Controllrt接口
 * @author guojing
 * @date 2014-3-3
 */
public interface Controller {

}
