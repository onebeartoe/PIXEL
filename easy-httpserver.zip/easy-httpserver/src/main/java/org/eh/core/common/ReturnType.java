package org.eh.core.common;

/**
 *
 * @author guojing
 * @date 2014-3-7
 */
public enum ReturnType {
	velocity, redirect, json
}
