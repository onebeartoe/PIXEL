#pragma once
#ifndef ES_APP_SCRAPER_CMD_LINE_H
#define ES_APP_SCRAPER_CMD_LINE_H

int run_scraper_cmdline();

#endif // ES_APP_SCRAPER_CMD_LINE_H
