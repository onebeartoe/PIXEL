#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 180
#error Unexpected pugixml version
#endif
